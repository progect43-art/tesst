import type { Product } from "@shared/commerce/types";
import { useCallback, useEffect, useMemo, useState } from "react";

const WISHLIST_STORAGE_KEY = "zon:wishlist:v1";

type WishlistItem = Pick<Product, "id" | "handle" | "title" | "productType" | "images" | "priceRange">;

function readWishlist(): WishlistItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(WISHLIST_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as WishlistItem[]) : [];
  } catch {
    return [];
  }
}

export function useWishlist() {
  const [items, setItems] = useState<WishlistItem[]>(readWishlist);

  useEffect(() => {
    window.localStorage.setItem(WISHLIST_STORAGE_KEY, JSON.stringify(items));
  }, [items]);

  const handles = useMemo(() => new Set(items.map(item => item.handle)), [items]);
  const isSaved = useCallback((handle: string) => handles.has(handle), [handles]);
  const toggle = useCallback((product: Product) => {
    setItems(current => current.some(item => item.handle === product.handle)
      ? current.filter(item => item.handle !== product.handle)
      : [...current, {
          id: product.id,
          handle: product.handle,
          title: product.title,
          productType: product.productType,
          images: product.images,
          priceRange: product.priceRange,
        }]);
  }, []);

  return { items, count: items.length, isSaved, toggle };
}
