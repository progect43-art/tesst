import { trpc } from "@/lib/trpc";
import { ArrowRight, CheckCircle2, ExternalLink, PackageSearch } from "lucide-react";
import { FormEvent, useState } from "react";
import { Link } from "wouter";

const statusLabels = {
  pending: "في انتظار التجهيز",
  processing: "جاري التجهيز",
  shipped: "تم الشحن",
  delivered: "تم التسليم",
  cancelled: "ملغي",
} as const;

export default function TrackOrder() {
  const [orderNumber, setOrderNumber] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [queryInput, setQueryInput] = useState<{ orderNumber: string; customerEmail: string } | null>(null);
  const query = trpc.orders.lookup.useQuery(queryInput ?? { orderNumber: "disabled", customerEmail: "disabled@example.com" }, { enabled: Boolean(queryInput) });

  const submit = (event: FormEvent) => {
    event.preventDefault();
    setQueryInput({ orderNumber: orderNumber.trim().toUpperCase(), customerEmail: customerEmail.trim().toLowerCase() });
  };

  return (
    <main className="track-page" dir="rtl">
      <header className="shop-topbar">
        <Link href="/" className="shop-wordmark"><img src="/manus-storage/zon-symbol_3b9490ff.png" alt="رمز ZON" /><span>ZON <small>STORE</small></span></Link>
        <Link href="/shop" className="shop-back">العودة للمتجر</Link>
      </header>
      <section className="track-shell">
        <div className="track-intro">
          <p className="eyebrow">ORDER STATUS / ZON STORE</p>
          <h1>اعرف طلبك<br /><span>وصل لفين.</span></h1>
          <p>اكتب رقم الطلب والبريد المستخدم أثناء الشراء، وهتظهر لك آخر حالة مسجلة للطلب.</p>
        </div>
        <form className="track-form" onSubmit={submit}>
          <label>رقم الطلب<input value={orderNumber} onChange={event => setOrderNumber(event.target.value)} placeholder="مثال: ZON-1004" required /></label>
          <label>البريد الإلكتروني<input type="email" value={customerEmail} onChange={event => setCustomerEmail(event.target.value)} placeholder="you@example.com" required /></label>
          <button type="submit" disabled={query.isFetching}><PackageSearch size={18} />{query.isFetching ? "جاري البحث..." : "تتبّع الطلب"}</button>
          <p className="track-privacy">لا نعرض بيانات الطلب إلا عند تطابق رقم الطلب والبريد الإلكتروني.</p>
        </form>
        {queryInput && !query.isFetching && query.data && (
          <div className="track-result track-success">
            <CheckCircle2 size={22} />
            <div><p className="eyebrow">{query.data.orderNumber}</p><h2>{statusLabels[query.data.status]}</h2><p>آخر تحديث محفوظ في النظام. لو عندك رابط شركة الشحن، هتلاقيه هنا.</p>{query.data.trackingUrl && <a href={query.data.trackingUrl} target="_blank" rel="noreferrer">افتح رابط الشحن <ExternalLink size={15} /></a>}</div>
          </div>
        )}
        {queryInput && !query.isFetching && !query.isError && query.data === null && <div className="track-result track-empty"><h2>مش لقينا الطلب.</h2><p>راجع رقم الطلب والبريد، أو تواصل مع ZON عبر Instagram.</p><a href="https://www.instagram.com/zon.storee/" target="_blank" rel="noreferrer">تواصل مع ZON <ExternalLink size={15} /></a></div>}
        {query.isError && <div className="track-result track-error"><h2>حصلت مشكلة أثناء البحث.</h2><p>تأكد من البيانات وحاول مرة أخرى.</p></div>}
      </section>
      <Link href="/" className="track-home-link"><ArrowRight size={16} /> الصفحة الرئيسية</Link>
    </main>
  );
}
