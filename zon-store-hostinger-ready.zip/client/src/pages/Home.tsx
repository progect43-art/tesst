/**
 * ZON Store design: "الشارع بعد الغروب" — streetwear editorial, charcoal surfaces,
 * signal-red decisions, asymmetrical compositions, Archivo Black + IBM Plex Sans Arabic.
 */
import { useState } from "react";
import { useCart } from "@/contexts/CartContext";
import {
  ArrowUpLeft,
  Instagram,
  Menu,
  MoveDownLeft,
  ShoppingBag,
  X,
} from "lucide-react";

const instagramUrl = "https://www.instagram.com/zon.storee/";

const navigation = [
  { label: "المتجر", href: "/shop" },
  { label: "تتبع الطلب", href: "/track-order" },
  { label: "الإصدار", href: "#drop" },
  { label: "عن ZON", href: "#about" },
  { label: "طريقة الطلب", href: "#order" },
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { itemCount, openCart } = useCart();

  const closeMenu = () => setMenuOpen(false);

  return (
    <main className="zon-page" dir="rtl">
      <header className="zon-header">
        <a className="zon-logo" href="#top" aria-label="العودة إلى بداية موقع ZON">
          <img src="/manus-storage/zon-symbol_3b9490ff.png" alt="رمز ZON" />
          <span className="zon-wordmark">ZON <small>STORE</small></span>
        </a>

        <nav className="desktop-nav" aria-label="التنقل الأساسي">
          {navigation.map((item) => (
            <a key={item.href} href={item.href}>{item.label}</a>
          ))}
        </nav>

        <div className="header-actions">
          <a className="header-cta" href="/shop"><span>ادخل المتجر</span><ShoppingBag size={16} strokeWidth={2.2} /></a>
          <button className="home-cart" type="button" onClick={openCart} aria-label="فتح سلة التسوق"><ShoppingBag size={18} /><span>{itemCount || 0}</span></button>
        </div>

        <button
          className="menu-button"
          type="button"
          onClick={() => setMenuOpen((open) => !open)}
          aria-label={menuOpen ? "إغلاق القائمة" : "فتح القائمة"}
          aria-expanded={menuOpen}
        >
          {menuOpen ? <X size={23} /> : <Menu size={23} />}
        </button>
      </header>

      {menuOpen && (
        <nav className="mobile-nav" aria-label="التنقل على الهاتف">
          {navigation.map((item) => (
            <a key={item.href} href={item.href} onClick={closeMenu}>{item.label}</a>
          ))}
          <a href="/shop" onClick={closeMenu}>
            ادخل المتجر <ArrowUpLeft size={17} />
          </a>
        </nav>
      )}

      <section className="hero" id="top" aria-labelledby="hero-title">
        <div className="hero-image" aria-hidden="true" />
        <div className="hero-grid" aria-hidden="true" />
        <div className="hero-copy">
          <p className="eyebrow">RELEASE 01 / CAIRO</p>
          <h1 id="hero-title">
            مش مجرد<br />
            <span>مقاس واسع.</span>
          </h1>
          <p className="hero-description">Oversized &amp; Box Fit معمولين لحضورك اليومي.</p>
          <div className="hero-actions">
            <a className="primary-button" href="/shop">
              <ShoppingBag size={18} />
              <span>شوف الإصدار</span>
            </a>
            <a className="text-button" href="#about">
              <span>اعرف ZON</span>
              <MoveDownLeft size={18} />
            </a>
          </div>
        </div>
        <div className="hero-index" aria-label="معرّف الإصدار">
          <span>DROP</span>
          <strong>01</strong>
          <span>/ 2026</span>
        </div>
        <div className="hero-corner-note">MADE FOR EVERYDAY CONFIDENCE</div>
      </section>

      <section className="ticker" aria-label="مزايا ZON Store">
        <div className="ticker-track">
          <span>OVERSIZED FIT</span><b>✳</b><span>BOX FIT</span><b>✳</b><span>SHIPPING ALL OVER EGYPT</span><b>✳</b><span>OVERSIZED FIT</span><b>✳</b><span>BOX FIT</span><b>✳</b><span>SHIPPING ALL OVER EGYPT</span><b>✳</b>
        </div>
      </section>

      <section className="drop-section" id="drop" aria-labelledby="drop-title">
        <div className="section-lead">
          <p className="eyebrow">THE CURRENT DROP</p>
          <div className="lead-row">
            <h2 id="drop-title">اختار الـ<span>fit</span> بتاعك.</h2>
            <p>قطع أساسية بصناعة نظيفة وتفاصيل تخلي اللوك كامل من أول مرة.</p>
          </div>
        </div>

        <div className="editorial-rail">
          <article className="product-card product-card-cream">
            <div className="product-image-wrap">
              <img src="/manus-storage/zon-lookbook-a_860e60c8.jpg" alt="إطلالة تيشيرت oversized بلون كريمي" />
              <span className="fit-badge">BOX FIT</span>
            </div>
            <div className="product-caption">
              <div>
                <p className="product-number">01 / TEE</p>
                <h3>Everyday Box Tee</h3>
              </div>
              <a href="/shop" aria-label="شاهد منتجات ZON Store">
                <ArrowUpLeft size={22} />
              </a>
            </div>
          </article>

          <article className="product-card product-card-hoodie">
            <div className="product-image-wrap">
              <img src="/manus-storage/zon-lookbook-b_a08a438d.jpg" alt="إطلالة هودي oversized بلون رمادي حجري" />
              <span className="fit-badge">OVERSIZED</span>
            </div>
            <div className="product-caption">
              <div>
                <p className="product-number">02 / HOODIE</p>
                <h3>After Hours Hoodie</h3>
              </div>
              <a href="/shop" aria-label="شاهد منتجات ZON Store">
                <ArrowUpLeft size={22} />
              </a>
            </div>
          </article>

          <article className="product-card product-card-note">
            <div className="release-number">03</div>
            <p className="eyebrow">ZON ESSENTIALS</p>
            <h3>كل قطعة تبدأ من الـfit الصح.</h3>
            <p className="note-copy">شوف الأسعار والمقاسات المتاحة وأضف القطعة لسلتك من المتجر.</p>
            <a className="red-link" href="/shop">
              ادخل المتجر <ArrowUpLeft size={18} />
            </a>
          </article>
        </div>
      </section>

      <section className="manifesto" id="about" aria-labelledby="manifesto-title">
        <div className="manifesto-texture" aria-hidden="true" />
        <div className="manifesto-copy">
          <p className="eyebrow">THE ZON CODE</p>
          <h2 id="manifesto-title">المقاس الواسع <span>مش هروب.</span><br />ده مساحة تبان فيها.</h2>
          <p>
            ZON معمولة للّوك اللي يتحرك معاك طول اليوم. قصّات مريحة، حضور واضح، وقطع تقدر تلبسها بطريقتك.
          </p>
          <div className="manifesto-stats" aria-label="مميزات ZON Store">
            <div><strong>01</strong><span>Oversized cuts</span></div>
            <div><strong>02</strong><span>Boxy silhouettes</span></div>
            <div><strong>03</strong><span>Delivered in Egypt</span></div>
          </div>
        </div>
      </section>

      <section className="order-section" id="order" aria-labelledby="order-title">
        <div className="order-heading">
          <p className="eyebrow">HOW TO ORDER</p>
          <h2 id="order-title">القطعة قريبة.<br /><span>والطلب أسهل.</span></h2>
        </div>
        <ol className="order-steps">
          <li>
            <span>01</span>
            <div><h3>اختار</h3><p>شوف القطع والصور والمقاسات المتاحة في المتجر.</p></div>
          </li>
          <li>
            <span>02</span>
            <div><h3>أضف للسلة</h3><p>اختار المقاس والكمية، ثم راجع طلبك قبل الإتمام.</p></div>
          </li>
          <li>
            <span>03</span>
            <div><h3>ادفع واستلم</h3><p>أكمل الدفع بالطريقة المفعّلة ثم استلم طلبك في مصر.</p></div>
          </li>
        </ol>
        <a className="instagram-panel" href={instagramUrl} target="_blank" rel="noreferrer">
          <span className="panel-mark"><Instagram size={27} /></span>
          <span><small>MESSAGE US ON</small><strong>@zon.storee</strong></span>
          <ArrowUpLeft className="panel-arrow" size={26} />
        </a>
      </section>

      <footer className="zon-footer">
        <div className="footer-brand">
          <img src="/manus-storage/zon-symbol_3b9490ff.png" alt="رمز ZON" />
          <div><strong>ZON</strong><span>STORE / CAIRO</span></div>
        </div>
        <p>OVERSIZED &amp; BOX FIT / EVERYDAY CONFIDENCE</p>
        <a href={instagramUrl} target="_blank" rel="noreferrer"><Instagram size={18} /> @zon.storee</a>
      </footer>
    </main>
  );
}
