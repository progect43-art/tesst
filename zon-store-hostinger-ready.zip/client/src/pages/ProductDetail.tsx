import { useCart } from "@/contexts/CartContext";
import { useWishlist } from "@/hooks/useWishlist";
import { formatMoney } from "@/lib/format";
import { trpc } from "@/lib/trpc";
import type { Product, ProductVariant } from "@shared/commerce/types";
import { ArrowRight, Heart, Minus, Plus, ShoppingBag } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";

function selectInitialOptions(product: Product): Record<string, string> {
  return Object.fromEntries(product.options.map(option => [option.name, option.values[0] ?? ""]));
}

function findVariant(product: Product, selections: Record<string, string>): ProductVariant | undefined {
  return product.variants.find(variant =>
    product.options.every(option => variant.selectedOptions.some(selected => selected.name === option.name && selected.value === selections[option.name]))
  ) ?? product.variants[0];
}

function ProductView({ product }: { product: Product }) {
  const [selections, setSelections] = useState<Record<string, string>>(() => selectInitialOptions(product));
  const [quantity, setQuantity] = useState(1);
  const { addItem, loading, itemCount, openCart } = useCart();
  const { isSaved, toggle } = useWishlist();
  const variant = useMemo(() => findVariant(product, selections), [product, selections]);
  const displayOptions = product.options.filter(option => !(option.name === "Title" && option.values.every(value => value === "Default Title")));

  useEffect(() => {
    setSelections(selectInitialOptions(product));
    setQuantity(1);
  }, [product]);

  const addToCart = async () => {
    if (!variant) return;
    await addItem(variant.id, quantity, {
      productHandle: product.handle,
      productTitle: product.title,
      variantTitle: variant.title,
      image: product.images[0] ?? null,
      unitPrice: variant.price,
    });
  };

  return (
    <main className="product-page" dir="rtl">
      <header className="shop-topbar">
        <Link href="/" className="shop-wordmark"><img src="/manus-storage/zon-symbol_3b9490ff.png" alt="رمز ZON" /><span>ZON <small>STORE</small></span></Link>
        <button className="shop-cart" type="button" onClick={openCart}><ShoppingBag size={18} /><span>السلة {itemCount ? `(${itemCount})` : ""}</span></button>
      </header>
      <div className="product-breadcrumb"><Link href="/shop"><ArrowRight size={17} />كل المنتجات</Link><span>/</span><span>{product.title}</span></div>
      <section className="product-detail">
        <div className="product-gallery" data-release={`DROP / ${product.productType || "ZON"}`}>
          {(product.images.length ? product.images : [{ url: "/manus-storage/zon-texture_507acf70.jpg", altText: product.title }]).map((image, index) => (
            <img src={image.url} alt={image.altText ?? product.title} key={`${image.url}-${index}`} />
          ))}
        </div>
        <div className="product-purchase">
          <p className="eyebrow">{product.productType || "ZON ESSENTIAL"}</p>
          <h1>{product.title}</h1>
          <p className="product-price">{variant ? formatMoney(variant.price) : formatMoney(product.priceRange.min)}</p>
          <p className="product-description">{product.description || "تفاصيل القطعة هتظهر هنا بمجرد إضافتها من إدارة المنتج."}</p>

          {displayOptions.map(option => (
            <fieldset className="product-options" key={option.name}>
              <legend>{option.name}</legend>
              <div>{option.values.map(value => <button className={selections[option.name] === value ? "selected" : ""} type="button" key={value} onClick={() => setSelections(current => ({ ...current, [option.name]: value }))}>{value}</button>)}</div>
            </fieldset>
          ))}

          <div className="purchase-row">
            <div className="detail-quantity">
              <button type="button" onClick={() => setQuantity(value => Math.max(1, value - 1))} aria-label="تقليل الكمية"><Minus size={16} /></button>
              <span>{quantity}</span>
              <button type="button" onClick={() => setQuantity(value => value + 1)} aria-label="زيادة الكمية"><Plus size={16} /></button>
            </div>
            <button className="add-to-cart" type="button" onClick={addToCart} disabled={!variant?.availableForSale || loading}>
              {!variant?.availableForSale ? "غير متاح حاليًا" : loading ? "جاري الإضافة..." : "أضف للسلة"}
              <ShoppingBag size={18} />
            </button>
          </div>
          <button className={`product-wishlist ${isSaved(product.handle) ? "saved" : ""}`} type="button" onClick={() => toggle(product)}><Heart size={17} fill={isSaved(product.handle) ? "currentColor" : "none"} />{isSaved(product.handle) ? "محفوظة في الأمنيات" : "احفظ القطعة"}</button>
          <p className="secure-note">تدفع بأمان عند إتمام الطلب من خلال صفحة الدفع الخاصة بالمتجر.</p>
        </div>
      </section>
    </main>
  );
}

export default function ProductDetail({ handle }: { handle: string }) {
  const { data: product, isLoading, isError } = trpc.commerce.products.byHandle.useQuery({ handle }, { enabled: Boolean(handle) });
  if (isLoading) return <main className="product-status" dir="rtl">جاري تحميل تفاصيل القطعة...</main>;
  if (isError || !product) return <main className="product-status" dir="rtl"><p>القطعة غير متاحة الآن.</p><Link href="/shop">ارجع للمتجر</Link></main>;
  return <ProductView product={product} />;
}
