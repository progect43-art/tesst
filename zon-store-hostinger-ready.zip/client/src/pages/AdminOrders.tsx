import AdminShell from "@/components/AdminShell";
import { Button } from "@/components/ui/button";
import { CheckCircle2, ClipboardList, FlaskConical, Info, Truck } from "lucide-react";
import { type FormEvent, useState } from "react";

type OrderStatus = "pending" | "processing" | "shipped" | "delivered" | "cancelled";

const statusLabels: Record<OrderStatus, string> = { pending: "في انتظار التجهيز", processing: "جاري التجهيز", shipped: "تم الشحن", delivered: "تم التسليم", cancelled: "ملغي" };

export default function AdminOrders() {
  const [orderNumber, setOrderNumber] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [status, setStatus] = useState<OrderStatus>("processing");
  const [trackingUrl, setTrackingUrl] = useState("");
  const [saved, setSaved] = useState(false);

  const submitDemoOrder = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); setSaved(true); };

  return <AdminShell title="إدارة الطلبات" eyebrow="ZON / ORDERS">
    <section className="flex flex-wrap items-end justify-between gap-5"><div><p className="text-sm leading-7 text-white/45">راجع الحالات وأكمل اختبار تدفق التتبع من مكان واحد.</p></div><span className="inline-flex items-center gap-2 rounded-full border border-amber-300/20 bg-amber-300/10 px-4 py-2 text-xs font-black text-amber-200"><span className="size-2 rounded-full bg-amber-300" />TEST MODE · مسودات فقط</span></section>
    <section className="mt-7 grid gap-4 sm:grid-cols-3"><MiniStat label="طلبات اليوم" value="—" detail="بانتظار الربط الفعلي" /><MiniStat label="قيد التجهيز" value="—" detail="بيانات Shopify غير موصولة" /><MiniStat label="حالة النظام" value="آمن" detail="لا حفظ في وضع الاختبار" /></section>
    <section className="mt-6 rounded-2xl border border-dashed border-white/15 bg-white/[0.02] p-6 text-center"><ClipboardList className="mx-auto text-white/25" size={28} /><h2 className="mt-3 text-lg font-black">لا توجد طلبات حقيقية للعرض</h2><p className="mt-2 text-sm leading-7 text-white/40">هذه الصفحة تعمل حاليًا كبيئة اختبار آمنة. ستظهر الطلبات هنا بعد تفعيل الربط التشغيلي مع Shopify وقاعدة البيانات.</p></section>
    <section className="mt-8 grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
      <form className="rounded-2xl border border-white/10 bg-[#141619] p-5 sm:p-8" onSubmit={submitDemoOrder}>
        <div className="flex items-start gap-4 border-b border-white/10 pb-6"><div className="grid size-11 shrink-0 place-items-center rounded-xl bg-[#ff3b30]/10 text-[#ff8079]"><ClipboardList size={22} /></div><div><h2 className="text-xl font-black">تحديث طلب تجريبي</h2><p className="mt-1 text-sm leading-6 text-white/40">استخدم بيانات غير حقيقية لاختبار الواجهة فقط.</p></div></div>
        <div className="mt-7 grid gap-5 md:grid-cols-2"><Field label="رقم الطلب التجريبي"><input className="admin-input" value={orderNumber} onChange={event => { setOrderNumber(event.target.value); setSaved(false); }} placeholder="ZON-TEST-1004" required /></Field><Field label="البريد التجريبي"><input type="email" className="admin-input" value={customerEmail} onChange={event => { setCustomerEmail(event.target.value); setSaved(false); }} placeholder="test@example.com" required /></Field></div>
        <div className="mt-5 grid gap-5 md:grid-cols-2"><Field label="الحالة"><select className="admin-input" value={status} onChange={event => { setStatus(event.target.value as OrderStatus); setSaved(false); }}>{Object.entries(statusLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></Field><Field label="رابط شحن تجريبي، اختياري"><input type="url" className="admin-input" value={trackingUrl} onChange={event => { setTrackingUrl(event.target.value); setSaved(false); }} placeholder="https://carrier.example/track/..." /></Field></div>
        <div className="mt-7 flex flex-wrap items-center gap-4"><Button type="submit" className="min-h-11 rounded-xl bg-[#ff3b30] px-6 font-black hover:bg-[#ff5148]">اختبار التحديث</Button>{saved && <span className="inline-flex items-center gap-2 text-sm font-bold text-emerald-300"><CheckCircle2 size={17} />نجح الاختبار — لم تُحفظ أي بيانات</span>}</div>
      </form>
      <aside className="rounded-2xl border border-white/10 bg-[#141619] p-5 sm:p-8"><div className="flex items-center gap-3"><span className="grid size-11 place-items-center rounded-xl bg-amber-300/10 text-amber-200"><FlaskConical size={22} /></span><div><p className="text-[10px] font-bold tracking-[0.2em] text-amber-300">ENVIRONMENT</p><h2 className="mt-1 text-xl font-black">حدود الوضع الحالي</h2></div></div><div className="mt-7 space-y-4"><Notice number="01" text="النموذج لا ينشئ طلبًا ولا يغيّر Shopify." /><Notice number="02" text="لا يتم تخزين البريد أو رقم الطلب التجريبي." /><Notice number="03" text="الربط الحي يحتاج تفعيل مسار الأدمن وقاعدة البيانات." /></div><div className="mt-7 rounded-xl border border-[#ff3b30]/20 bg-[#ff3b30]/5 p-4 text-sm leading-7 text-white/55"><Info className="ml-2 inline-block text-[#ff8079]" size={17} />حماية backend موجودة، بينما هذه الشاشة مصممة حاليًا للاختبار الآمن فقط.</div></aside>
    </section>
    <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.03] p-5 text-sm leading-7 text-white/50"><Truck className="ml-2 inline-block text-[#ff8079]" size={17} />عند تفعيل الربط الفعلي، ستظهر هنا قائمة الطلبات، الفلاتر، سجل التغييرات، وحالة المزامنة مع Shopify.</div>
  </AdminShell>;
}

function Field({ label, children }: { label: string; children: React.ReactNode }) { return <label className="grid gap-2 text-sm font-bold text-white/75">{label}{children}</label>; }
function Notice({ number, text }: { number: string; text: string }) { return <div className="flex gap-3 rounded-xl border border-white/10 bg-white/[0.02] p-4"><span className="font-mono text-sm font-black text-[#ff8079]">{number}</span><p className="text-sm leading-7 text-white/55">{text}</p></div>; }
function MiniStat({ label, value, detail }: { label: string; value: string; detail: string }) { return <article className="rounded-2xl border border-white/10 bg-[#141619] p-5"><p className="text-xs text-white/40">{label}</p><p className="mt-3 text-2xl font-black">{value}</p><p className="mt-2 text-[11px] text-white/30">{detail}</p></article>; }
