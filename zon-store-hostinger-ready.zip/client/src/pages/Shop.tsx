import { useCart } from "@/contexts/CartContext";
import { useWishlist } from "@/hooks/useWishlist";
import { formatMoney } from "@/lib/format";
import { trpc } from "@/lib/trpc";
import { ArrowUpLeft, Heart, Search, ShoppingBag, SlidersHorizontal, X } from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "wouter";

export default function Shop() {
  const { data: products = [], isLoading, isError } = trpc.commerce.products.list.useQuery({ first: 50 });
  const { itemCount, openCart } = useCart();
  const { count: wishlistCount, isSaved, toggle } = useWishlist();
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const productTypes = useMemo(() => ["all", ...Array.from(new Set(products.map(product => product.productType).filter(Boolean) as string[]))], [products]);
  const filteredProducts = useMemo(() => {
    const normalizedSearch = search.trim().toLowerCase();
    const min = minPrice ? Number(minPrice) : 0;
    const max = maxPrice ? Number(maxPrice) : Number.POSITIVE_INFINITY;
    return products.filter(product => {
      const searchable = [product.title, product.productType ?? "", product.vendor ?? "", ...product.tags].join(" ").toLowerCase();
      const price = Number(product.priceRange.min.amount);
      return (!normalizedSearch || searchable.includes(normalizedSearch))
        && (typeFilter === "all" || product.productType === typeFilter)
        && price >= min
        && price <= max;
    });
  }, [maxPrice, minPrice, products, search, typeFilter]);

  const clearFilters = () => { setSearch(""); setTypeFilter("all"); setMinPrice(""); setMaxPrice(""); };
  const hasFilters = Boolean(search || typeFilter !== "all" || minPrice || maxPrice);

  return (
    <main className="shop-page" dir="rtl">
      <header className="shop-topbar">
        <Link href="/" className="shop-wordmark"><img src="/manus-storage/zon-symbol_3b9490ff.png" alt="رمز ZON" /><span>ZON <small>STORE</small></span></Link>
        <div className="shop-topbar-actions">
          <Link href="/" className="shop-back">الصفحة الرئيسية</Link>
          <Link href="#wishlist" className="shop-wishlist-link" aria-label={`الأمنيات ${wishlistCount}`}><Heart size={17} fill={wishlistCount ? "currentColor" : "none"} />{wishlistCount}</Link>
          <button className="shop-cart" type="button" onClick={openCart}><ShoppingBag size={18} /><span>السلة {itemCount ? `(${itemCount})` : ""}</span></button>
        </div>
      </header>

      <section className="shop-hero">
        <p className="eyebrow">LIVE CATALOG / ZON STORE</p>
        <h1>الإصدار <span>الحالي.</span></h1>
        <p>ابحث عن القطعة، صفّي حسب النوع والسعر، واحفظ اللي عجبك قبل الشراء.</p>
      </section>

      <section className="catalog-section" aria-label="كتالوج المنتجات">
        <div className="catalog-toolbar">
          <label className="catalog-search"><Search size={18} /><span className="sr-only">ابحث في المنتجات</span><input value={search} onChange={event => setSearch(event.target.value)} placeholder="دوّر على القطعة أو الـfit..." /></label>
          <button className={`filter-toggle ${showFilters ? "active" : ""}`} type="button" onClick={() => setShowFilters(value => !value)}><SlidersHorizontal size={17} /> الفلاتر</button>
          {hasFilters && <button className="clear-filters" type="button" onClick={clearFilters}>مسح الكل <X size={14} /></button>}
        </div>
        {showFilters && <div className="filter-panel">
          <label>النوع<select value={typeFilter} onChange={event => setTypeFilter(event.target.value)}>{productTypes.map(type => <option value={type} key={type}>{type === "all" ? "كل الأنواع" : type}</option>)}</select></label>
          <label>أقل سعر<input type="number" min="0" value={minPrice} onChange={event => setMinPrice(event.target.value)} placeholder="0" /></label>
          <label>أعلى سعر<input type="number" min="0" value={maxPrice} onChange={event => setMaxPrice(event.target.value)} placeholder="بدون حد" /></label>
          <p>{filteredProducts.length} قطعة مطابقة</p>
        </div>}
        {isLoading && <div className="catalog-status">جاري تحميل القطع المتاحة...</div>}
        {isError && <div className="catalog-status catalog-error">تعذر تحميل الكتالوج الآن. جرّب مرة أخرى بعد قليل.</div>}
        {!isLoading && !isError && products.length === 0 && <div className="catalog-status"><strong>الإصدار القادم تحت التجهيز.</strong><span>أضف أول منتجاتك من لوحة Shopify، وهتظهر هنا تلقائيًا.</span></div>}
        {!isLoading && !isError && products.length > 0 && filteredProducts.length === 0 && <div className="catalog-status"><strong>مفيش نتيجة بالمواصفات دي.</strong><span>جرّب تغيّر البحث أو توسّع نطاق السعر.</span></div>}
        <div className="catalog-grid">
          {filteredProducts.map((product, index) => (
            <article className="store-product-card" key={product.id}>
              <Link className="store-product-link" href={`/product/${product.handle}`}>
                <div className="store-product-image">
                  <img src={product.images[0]?.url ?? "/manus-storage/zon-texture_507acf70.jpg"} alt={product.images[0]?.altText ?? product.title} />
                  <span>DROP / {String(index + 1).padStart(2, "0")}</span>
                </div>
                <div className="store-product-copy"><div><p>{product.productType || "ZON ESSENTIAL"}</p><h2>{product.title}</h2></div><div className="store-product-price"><strong>{formatMoney(product.priceRange.min)}</strong><ArrowUpLeft size={20} /></div></div>
              </Link>
              <button className={`wishlist-button ${isSaved(product.handle) ? "saved" : ""}`} type="button" onClick={() => toggle(product)} aria-label={isSaved(product.handle) ? `إزالة ${product.title} من الأمنيات` : `حفظ ${product.title} في الأمنيات`}><Heart size={19} fill={isSaved(product.handle) ? "currentColor" : "none"} /></button>
            </article>
          ))}
        </div>
        <section className="wishlist-note" id="wishlist"><Heart size={18} fill={wishlistCount ? "currentColor" : "none"} /><span>{wishlistCount ? `حافظ ${wishlistCount} ${wishlistCount === 1 ? "قطعة" : "قطع"} في قائمة الأمنيات.` : "احفظ القطع اللي لسه بتفكر فيها قبل ما تخلص."}</span></section>
      </section>
    </main>
  );
}
