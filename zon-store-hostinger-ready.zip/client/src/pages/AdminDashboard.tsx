import AdminShell from "@/components/AdminShell";
import { trpc } from "@/lib/trpc";
import { ArrowUpLeft, Boxes, ClipboardList, ExternalLink, PackageCheck, Percent, Plus, ShieldCheck, Sparkles, TrendingUp } from "lucide-react";
import { useMemo } from "react";
import type { Product } from "@shared/commerce/types";
import { Link } from "wouter";

function formatPrice(value: string | number) {
  return `${Number(value).toLocaleString("en-US")} ج.م`;
}

export function getAdminCatalogSummary(products: Product[]) {
  const totalProducts = products.length;
  const tShirts = products.filter(product => product.productType?.toLowerCase().includes("shirt")).length;
  const averagePrice = totalProducts ? products.reduce((sum, product) => sum + Number(product.priceRange.min.amount), 0) / totalProducts : 0;
  return { totalProducts, tShirts, averagePrice };
}

export default function AdminDashboard() {
  const productInput = useMemo(() => ({ first: 25 }), []);
  const productsQuery = trpc.commerce.products.list.useQuery(productInput, { retry: 1 });
  const products = productsQuery.data ?? [];
  const { totalProducts, tShirts, averagePrice } = getAdminCatalogSummary(products);

  return (
    <AdminShell title="نظرة عامة" eyebrow="ZON / ADMIN DASHBOARD">
      <section className="relative overflow-hidden rounded-[28px] border border-white/10 bg-[radial-gradient(circle_at_80%_20%,rgba(255,59,48,0.2),transparent_35%),linear-gradient(135deg,#1d2024,#121416)] p-6 sm:p-8 lg:p-10">
        <div className="relative z-10 max-w-2xl"><div className="inline-flex items-center gap-2 rounded-full border border-[#ff5a50]/30 bg-[#ff3b30]/10 px-3 py-1.5 text-xs font-bold text-[#ff8f89]"><Sparkles size={14} /> CONTROL ROOM · LIVE CATALOG</div><h2 className="mt-5 text-3xl font-black leading-tight tracking-tight sm:text-5xl">مساحة التحكم في <span className="text-[#ff5148]">ZON</span>.</h2><p className="mt-4 max-w-xl text-sm leading-7 text-white/55 sm:text-base">تابع أداء الكتالوج، راجع حالة الأدوات الإدارية، وانتقل بسرعة إلى أهم مهام التشغيل من واجهة واحدة مرتبة.</p><div className="mt-7 flex flex-wrap gap-3"><Link href="/admin/discounts" className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-[#ff3b30] px-5 text-sm font-black text-white shadow-[0_12px_30px_rgba(255,59,48,0.2)] transition-transform hover:-translate-y-0.5">إنشاء مسودة خصم<Plus size={17} /></Link><Link href="/shop" className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-white/15 px-5 text-sm font-bold text-white/75 transition-colors hover:border-white/30 hover:text-white">مشاهدة المتجر<ExternalLink size={16} /></Link></div></div><div className="pointer-events-none absolute -left-10 -top-16 hidden text-[220px] font-black italic leading-none text-white/[0.025] sm:block">Z</div>
      </section>

      <section className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-6">
        <StatCard label="إجمالي المنتجات" value={productsQuery.isLoading ? "—" : totalProducts} detail="من Shopify Catalog" icon={Boxes} tone="red" />
        <StatCard label="تيشيرتات نشطة" value={productsQuery.isLoading ? "—" : tShirts} detail="Oversized / Graphic" icon={PackageCheck} tone="violet" />
        <StatCard label="متوسط السعر" value={productsQuery.isLoading ? "—" : formatPrice(averagePrice)} detail="حسب الكتالوج الحالي" icon={TrendingUp} tone="amber" />
        <StatCard label="الطلبات" value="تجريبي" detail="الربط قيد التفعيل" icon={ClipboardList} tone="amber" />
        <StatCard label="أكواد الخصم" value="محلي" detail="مسودات فقط" icon={Percent} tone="violet" />
        <StatCard label="حالة الحماية" value="مفعّلة" detail="Admin + rate limit" icon={ShieldCheck} tone="green" />
      </section>

      <section className="mt-8 grid gap-6 xl:grid-cols-[1.25fr_0.75fr]">
        <div className="rounded-2xl border border-white/10 bg-[#141619] p-5 sm:p-7"><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="text-[10px] font-bold tracking-[0.2em] text-[#ff5a50]">CATALOG SNAPSHOT</p><h3 className="mt-2 text-xl font-black">المنتجات الحالية</h3></div><Link href="/shop" className="inline-flex items-center gap-2 text-xs font-bold text-white/50 hover:text-white">فتح الكتالوج<ArrowUpLeft size={15} /></Link></div><div className="mt-6 divide-y divide-white/10">{productsQuery.isLoading ? <div className="py-8 text-sm text-white/40">جاري تحميل بيانات Shopify…</div> : productsQuery.isError ? <div className="rounded-xl border border-red-300/15 bg-red-300/5 p-5 text-sm leading-7 text-red-100">تعذر تحميل الكتالوج حاليًا. جرّب تحديث الصفحة أو تحقق من اتصال Shopify.</div> : products.length === 0 ? <div className="rounded-xl border border-dashed border-white/15 p-8 text-center text-sm leading-7 text-white/35">لا توجد منتجات متاحة حاليًا.</div> : products.slice(0, 5).map(product => <div key={product.handle} className="flex items-center justify-between gap-4 py-4"><div className="flex min-w-0 items-center gap-3"><div className="size-11 shrink-0 overflow-hidden rounded-xl bg-white/10">{product.images[0]?.url ? <img src={product.images[0].url} alt="" className="size-full object-cover" /> : <div className="grid size-full place-items-center text-white/30"><Boxes size={17} /></div>}</div><div className="min-w-0"><p className="truncate text-sm font-bold">{product.title}</p><p className="mt-1 text-xs text-white/40">{product.productType ?? "منتج"} · {product.variants.length} مقاسات</p></div></div><span className="shrink-0 text-sm font-black text-[#ff8079]">{formatPrice(product.priceRange.min.amount)}</span></div>)}</div></div>
        <div className="space-y-6"><div className="rounded-2xl border border-white/10 bg-[#141619] p-5 sm:p-7"><div className="flex items-center justify-between"><div><p className="text-[10px] font-bold tracking-[0.2em] text-amber-300">OPERATIONS</p><h3 className="mt-2 text-xl font-black">إجراءات سريعة</h3></div><ClipboardList className="text-white/30" size={22} /></div><div className="mt-5 grid gap-3"><QuickLink href="/admin/orders" icon={ClipboardList} title="إدارة الطلبات" description="وضع الاختبار الحالي" /><QuickLink href="/admin/discounts" icon={Percent} title="أكواد الخصم" description="مسودات محلية آمنة" /></div></div><div className="rounded-2xl border border-emerald-300/15 bg-emerald-300/5 p-5 sm:p-7"><div className="flex items-start gap-3"><ShieldCheck className="mt-0.5 shrink-0 text-emerald-300" size={20} /><div><h3 className="font-black text-emerald-100">مراجعة أمان</h3><p className="mt-2 text-sm leading-7 text-white/50">لا يتم عرض أسرار Shopify في المتصفح، وبيانات الخصومات تحفظ كمسودات فقط حتى اعتمادها من Shopify.</p></div></div></div></div>
      </section>
    </AdminShell>
  );
}

function StatCard({ label, value, detail, icon: Icon, tone }: { label: string; value: string | number; detail: string; icon: typeof Boxes; tone: "red" | "violet" | "amber" | "green" }) {
  const colors = { red: "bg-red-400/10 text-red-300", violet: "bg-violet-400/10 text-violet-300", amber: "bg-amber-300/10 text-amber-200", green: "bg-emerald-300/10 text-emerald-300" };
  return <article className="rounded-2xl border border-white/10 bg-[#141619] p-5"><div className="flex items-start justify-between gap-3"><div><p className="text-xs text-white/45">{label}</p><p className="mt-3 text-2xl font-black tracking-tight">{value}</p><p className="mt-2 text-[11px] text-white/35">{detail}</p></div><span className={`grid size-10 place-items-center rounded-xl ${colors[tone]}`}><Icon size={19} /></span></div></article>;
}

function QuickLink({ href, icon: Icon, title, description }: { href: string; icon: typeof ClipboardList; title: string; description: string }) {
  return <Link href={href} className="group flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.02] p-3 transition-colors hover:border-[#ff5a50]/40 hover:bg-[#ff3b30]/5"><span className="grid size-10 place-items-center rounded-lg bg-white/5 text-white/55 group-hover:text-[#ff817a]"><Icon size={17} /></span><span className="min-w-0"><strong className="block text-sm">{title}</strong><small className="mt-1 block text-xs text-white/35">{description}</small></span><ArrowUpLeft className="mr-auto text-white/25 transition-transform group-hover:-translate-x-0.5 group-hover:text-white/60" size={16} /></Link>;
}
